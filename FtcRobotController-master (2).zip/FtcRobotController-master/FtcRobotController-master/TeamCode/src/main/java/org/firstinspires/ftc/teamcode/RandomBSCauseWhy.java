package org.firstinspires.ftc.teamcode;

//important imports so the robot knows what to do
import com.qualcomm.hardware.limelightvision.LLResult;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.hardware.limelightvision.Limelight3A;

import org.firstinspires.ftc.robotcore.external.navigation.Pose3D;

@TeleOp
public class RandomBSCauseWhy extends LinearOpMode {
    private DcMotor FLW;
    private DcMotor FRW;
    private DcMotor BLW;
    private DcMotor BRW;
    private DcMotorEx NectarShooter;
    private DcMotor NectarCollecter;
    private CRServo Propeller;
    private Limelight3A Limelight;

    @Override
    public void runOpMode() throws InterruptedException {


        //Tells driver hub what is what
        DcMotor FRW = hardwareMap.dcMotor.get("FRW");
        DcMotor FLW = hardwareMap.dcMotor.get("FLW");
        DcMotor BRW = hardwareMap.dcMotor.get("BRW");
        DcMotor BLW = hardwareMap.dcMotor.get("BLW");
        NectarShooter = hardwareMap.get(DcMotorEx.class, "NectarShooter");
        DcMotor NectarCollecter = hardwareMap.dcMotor.get("NectarCollecter");
        Limelight = hardwareMap.get(Limelight3A.class, "limelight");

        CRServo Propeller = hardwareMap.crservo.get("Propeller");

        telemetry.setMsTransmissionInterval(11);

        Limelight.pipelineSwitch(0);
        Limelight.start();

        waitForStart();
        while (opModeIsActive()) {

            //Set motor to sleep when not used
            FLW.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
            BLW.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
            FRW.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
            BRW.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);


            BRW.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
            FRW.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
            BLW.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
            FLW.setMode(DcMotor.RunMode.RUN_USING_ENCODER);

            NectarShooter.setMode(DcMotorEx.RunMode.RUN_USING_ENCODER);

            LLResult result = Limelight.getLatestResult();

            if (result != null) {
                if (result.isValid()) {
                    Pose3D botpose = result.getBotpose();
                    telemetry.addData("tx", result.getTx());
                    telemetry.addData("ty", result.getTy());
                    telemetry.addData("Botpose", botpose.toString());
                }
            }


            //Drive, which is what makes it move
            double y = -gamepad1.left_stick_y;
            double x = -gamepad1.left_stick_x;
            double rx = .8 * (gamepad1.right_stick_x);


            double denominator = Math.max(Math.abs(y) + Math.abs(x) + Math.abs(rx), 1.1);
            double frontLeftPower = (y - x + rx) / denominator;
            double backLeftPower = (y + x + rx) / denominator;
            double frontRightPower = (y + x - rx) / denominator;
            double backRightPower = (y - x - rx) / denominator;


            //So intervals are flipped, Don't mess unless needed
            FLW.setPower(frontLeftPower * 1);
            BLW.setPower(backLeftPower * 1);
            FRW.setPower(frontRightPower * -1);
            BRW.setPower(backRightPower * -1);

            //Mechanism, set as drivers need
            if (gamepad2.triangle) {
                NectarCollecter.setPower(1);
            } else {
                NectarCollecter.setPower(0);
            }
            if (gamepad2.right_trigger > .05) {
                NectarShooter.setVelocity(167);
            } else if (gamepad2.left_trigger > .05) {
                NectarShooter.setVelocity(160);
            } else if (gamepad2.circle){
                NectarShooter.setVelocity(-225);
            } else{
                NectarShooter.setVelocity(0);
            }

            if (gamepad2.square) {
                Propeller.setPower(1);
            } else {
                Propeller.setPower(0);


            }
        }
    }
}

