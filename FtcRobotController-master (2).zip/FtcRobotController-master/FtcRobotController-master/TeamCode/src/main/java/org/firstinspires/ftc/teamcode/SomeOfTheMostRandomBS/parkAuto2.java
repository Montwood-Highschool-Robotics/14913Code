//package org.firstinspires.ftc.teamcode.SomeOfTheMostRandomBS;
//
//import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
//import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
//import com.qualcomm.robotcore.hardware.DcMotor;
//import com.qualcomm.robotcore.util.ElapsedTime;
//
//
//@Autonomous
//public class parkAuto2 extends LinearOpMode {
//    private DcMotor FLW;
//    private DcMotor FRW;
//    private DcMotor BLW;
//    private DcMotor BRW;
//    static final double COUNTS_PER_MOTOR_REV = 383.6;
//    static final double DRIVE_GEAR_REDUCTION = 1.0;
//    static final double WHEEL_DIAMETER_INCHES = 3.937;
//    static final double COUNTS_PER_INCH = (COUNTS_PER_MOTOR_REV * DRIVE_GEAR_REDUCTION) / (WHEEL_DIAMETER_INCHES * 3.1415);
//
//    @Override
//    public void runOpMode() throws InterruptedException {
//        FLW = hardwareMap.dcMotor.get("FLW");
//        FRW = hardwareMap.dcMotor.get("FRW");
//        BRW = hardwareMap.dcMotor.get("BRW");
//        BLW = hardwareMap.dcMotor.get("BLW");
//
//        FLW.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
//        FRW.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
//        BRW.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
//        BLW.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
//
//        FLW.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
//        FRW.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
//        BRW.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
//        BLW.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
//
//
//        waitForStart();
//
//    }
//
//    public void driveFoward(double speed, double dist, double timeout) {
//        encoderDrive (speed,dist, dist, timeout);
//    }
//
//    private void encoderDrive(double speed, double distL, double distR, double timeout) {
//        int newLeftTarget;
//        int newRightTarget;
//
//        if (opModeIsActive()){
//
//
//            newLeftTarget = FLW.getCurrentPosition() + (int) (distL * COUNTS_PER_INCH);
//            newRightTarget = FRW.getCurrentPosition()  + (int) (distR * COUNTS_PER_INCH);
//
//            FLW.setTargetPosition(-newLeftTarget);
//            BLW.setTargetPosition(-newLeftTarget);
//            BRW.setTargetPosition(newRightTarget);
//            FRW.setTargetPosition(newRightTarget);
//
//            FLW.setMode(DcMotor.RunMode.RUN_TO_POSITION);
//            BLW.setMode(DcMotor.RunMode.RUN_TO_POSITION);
//            BRW.setMode(DcMotor.RunMode.RUN_TO_POSITION);
//            FRW.setMode(DcMotor.RunMode.RUN_TO_POSITION);
//
//            FLW.setPower(Math.abs(speed));
//            BLW.setPower(Math.abs(speed));
//            BRW.setPower(Math.abs(speed));
//            FRW.setPower(Math.abs(speed));
//
//            FLW.setPower(0);
//            BLW.setPower(0);
//            BRW.setPower(0);
//            FRW.setPower(0);
//
//            FLW.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
//            BLW.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
//            BRW.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
//            FRW.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
//
//            FLW.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
//            BLW.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
//            BRW.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
//            FRW.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
//
//
//    }
//}}
//
